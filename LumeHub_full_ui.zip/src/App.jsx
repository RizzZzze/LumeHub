import React, { useState } from "react";
import ValidatorTab from "./components/ValidatorTab.jsx";
import GovernanceTab from "./components/GovernanceTab.jsx";
import NodeStatus from "./components/NodeStatus.jsx";
import WalletTab from "./components/WalletTab.jsx";
import CosmWasmPlayground from "./components/CosmWasmPlayground.jsx";

const tabs = ["Wallet", "Validators", "Governance", "Wasm"];
const Btn = ({ t, a, on }) => (
  <button onClick={() => on(t)} style={{
    padding:"10px 14px", borderRadius:10, border:"1px solid #36365a",
    background: a===t? "rgba(0,255,255,0.12)" : "rgba(255,255,255,0.03)",
    color:"white", cursor:"pointer"}}>{t}</button>
);

export default function App(){
  const [tab,setTab]=useState("Wallet");
  return (
    <div style={{minHeight:"100vh",background:"radial-gradient(circle at top,#141428,#05050c)",color:"white",padding:24,fontFamily:"Inter,system-ui,sans-serif"}}>
      <div style={{maxWidth:1000,margin:"0 auto"}}>
        <h1 style={{margin:0}}>🌌 LumeHub</h1>
        <p style={{opacity:.8,margin:"6px 0 18px"}}>Your all-in-one Lumera Testnet Explorer</p>
        <div style={{display:"flex",gap:8,marginBottom:16,flexWrap:"wrap"}}>
          {tabs.map(t => <Btn key={t} t={t} a={tab} on={setTab} />)}
        </div>
        {tab==="Wallet" && <WalletTab/>}
        {tab==="Validators" && <ValidatorTab/>}
        {tab==="Governance" && <GovernanceTab/>}
        {tab==="Wasm" && <CosmWasmPlayground/>}
        <p style={{opacity:.5,marginTop:28}}>© 2025 LumeHub — Lumera Protocol</p>
      </div>
    </div>
  );
}
