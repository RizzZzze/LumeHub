import React, { useEffect, useState } from "react";
import { LCDS } from "../config.js";

const TEST_PATH = "/cosmos/base/tendermint/v1beta1/blocks/latest";

async function ping(url) {
  const started = performance.now();
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort("timeout"), 5000);
    const r = await fetch(url + TEST_PATH, {
      signal: ctrl.signal,
      headers: { accept: "application/json" },
      cache: "no-store",
    });
    clearTimeout(t);
    return {
      ok: r.ok,
      ms: Math.round(performance.now() - started),
      status: r.status,
    };
  } catch (e) {
    return { ok: false, ms: Math.round(performance.now() - started), err: String(e) };
  }
}

export default function NodeStatus() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let alive = true;
    (async () => {
      setLoading(true);
      const res = [];
      for (const base of LCDS) {
        const p = await ping(base);
        res.push({ base, ...p });
      }
      if (alive) {
        res.sort((a,b) => Number(b.ok) - Number(a.ok) || a.ms - b.ms);
        setRows(res);
        setLoading(false);
      }
    })();
    return () => { alive = false };
  }, []);

  return (
    <div style={{maxWidth: 900}}>
      <h2>Node Status</h2>
      <p>Quick health-check across known Lumera testnet LCD endpoints.</p>
      {loading && <p>Checking endpoints…</p>}
      {!loading && (
        <table style={{width: "100%", borderCollapse: "collapse"}}>
          <thead>
            <tr>
              <th style={{textAlign:"left", padding:"8px"}}>Endpoint</th>
              <th style={{textAlign:"left", padding:"8px"}}>OK</th>
              <th style={{textAlign:"left", padding:"8px"}}>Latency</th>
              <th style={{textAlign:"left", padding:"8px"}}>Status</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r, i) => (
              <tr key={i} style={{borderTop:"1px solid rgba(255,255,255,0.08)"}}>
                <td style={{padding:"8px", wordBreak:"break-all"}}>{r.base}</td>
                <td style={{padding:"8px"}}>{r.ok ? "✅" : "❌"}</td>
                <td style={{padding:"8px"}}>{r.ms} ms</td>
                <td style={{padding:"8px"}}>{r.status || r.err || "-"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
